package org.activiti;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.cmd.SignalCmd;
import org.activiti.engine.impl.interceptor.CommandExecutor;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;

import static org.junit.Assert.*;

public class MyUnitTest {
	
	@Rule
	public ActivitiRule activitiRule = new ActivitiRule();
	
	@Test
	@Deployment(resources = {"org/activiti/test/TestSendTo.bpmn"})
	public void test() {
		
		RuntimeService runtimeService = activitiRule.getRuntimeService();
		TaskService taskService = activitiRule.getTaskService();
		ProcessEngineConfiguration processEngineConfiguration = activitiRule.getProcessEngine().getProcessEngineConfiguration();
		
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put("goToUserTask", true);
		
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("TestSendTo", variables);
		assertNotNull(processInstance);

		Task task = taskService.createTaskQuery().singleResult();
		assertEquals("User Task 1", task.getName());
	
		taskService.complete(task.getId());
		
		processInstance = runtimeService.createProcessInstanceQuery().
							processInstanceId(processInstance.getProcessInstanceId()).singleResult();

		task = taskService.createTaskQuery().singleResult();
		assertEquals("User Task 2", task.getName());
	
		taskService.complete(task.getId());
	
		processInstance = runtimeService.createProcessInstanceQuery().
				processInstanceId(processInstance.getProcessInstanceId()).singleResult();

		assertEquals("receivetask1", processInstance.getActivityId());
		
		Execution execution = runtimeService.createExecutionQuery().
				processInstanceId(processInstance.getProcessInstanceId()).singleResult();
		
		runtimeService.setVariable(execution.getId(), "goToUserTask", true);
		
		ProcessEngineConfigurationImpl processEngineConfigurationImpl = (ProcessEngineConfigurationImpl) processEngineConfiguration;
		CommandExecutor commandExecutor = processEngineConfigurationImpl.getCommandExecutor();
		commandExecutor.execute(new RestartInstanceActivitiCommand(execution.getId(), "servicetask1"));
		commandExecutor.execute(new SignalCmd(execution.getId(), "compensationDone", null, null));

		processInstance = runtimeService.createProcessInstanceQuery().
				processInstanceId(processInstance.getProcessInstanceId()).singleResult();
		assertEquals("Process instance should have moved to userTask1!", "userTask1", processInstance.getActivityId());
		
	}

}
